# View-on-Same-Tab
A Mozilla Firefox add-on for viewing images and videos on same tab
